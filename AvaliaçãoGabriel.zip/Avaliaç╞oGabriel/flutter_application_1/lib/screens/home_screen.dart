import 'package:flutter/material.dart';
import '../models/livro.dart';

class HomeScreen extends StatelessWidget {
  final String nome;

  // Construtor sem const (agora comum)
  HomeScreen({super.key, required this.nome});

  // Lista comum (não constante)
  final List<Livro> _ultimosLivros = [
    Livro(titulo: 'O Hobbit', autor: 'J.R.R. Tolkien'),
    Livro(titulo: '1984', autor: 'George Orwell'),
    Livro(titulo: 'Dom Casmurro', autor: 'Machado de Assis'),
    Livro(titulo: 'O Pequeno Príncipe', autor: 'Antoine de Saint-Exupéry'),
    Livro(titulo: 'A Revolução dos Bichos', autor: 'George Orwell'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Controle de Leitura'),
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Olá, $nome!',
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Últimos livros lidos:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: _ultimosLivros.length,
                itemBuilder: (context, index) {
                  final livro = _ultimosLivros[index];
                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 6),
                    child: ListTile(
                      leading: const Icon(Icons.book),
                      title: Text(livro.titulo),
                      subtitle: Text(livro.autor),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}